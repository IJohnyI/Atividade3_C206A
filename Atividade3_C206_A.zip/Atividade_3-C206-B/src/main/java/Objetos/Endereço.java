package Objetos;

public class Endereço {
    public String rua;
    public String bairro;
    public int numero;

    public Endereço(String rua, String bairro, int numero){
        this.rua = rua;
        this.bairro = bairro;
        this.numero = numero;
    }
}